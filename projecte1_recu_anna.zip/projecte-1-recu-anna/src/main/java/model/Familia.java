/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.time.LocalDate;

/**
 * Classe que representa una família de productes a la base de dades. Conté
 * informació rellevant sobre la família, com el nom, la descripció, la data
 * d'alta, l'ID del proveïdor i observacions addicionals.
 *
 * @autor oriol
 */
public class Familia {

    private int id_fam;
    private String nom_familia;
    private String descripcio;
    private LocalDate data_alta_fam;
    private int id_proveidor_fam;
    private String Observacions;

    /**
     * Constructor de la classe Familia.
     *
     * @param id_fam ID únic de la família.
     * @param nom_familia Nom de la família.
     * @param descripcio Descripció de la família.
     * @param data_alta_fam Data d'alta de la família.
     * @param id_proveidor_fam ID del proveïdor associat a la família.
     * @param Observacions Observacions addicionals sobre la família.
     */
    public Familia(int id_fam, String nom_familia, String descripcio, LocalDate data_alta_fam, int id_proveidor_fam, String Observacions) {
        this.id_fam = id_fam;
        this.nom_familia = nom_familia;
        this.descripcio = descripcio;
        this.data_alta_fam = data_alta_fam;
        this.id_proveidor_fam = id_proveidor_fam;
        this.Observacions = Observacions;
    }

    /**
     * Constructor per defecte de la classe Familia. Aquest constructor
     * inicialitza una nova instància de la classe Familia sense establir els
     * valors dels atributs. Es pot utilitzar per crear una nova instància de la
     * classe i posteriorment establir els valors a través dels mètodes setters.
     */
    public Familia() {
    }

    /**
     * Estableix l'ID de la família.
     *
     * @param id_fam ID únic de la família.
     */
    public void setId_fam(int id_fam) {
        this.id_fam = id_fam;
    }

    /**
     * Estableix el nom de la família.
     *
     * @param nom_familia Nom de la família.
     */
    public void setNom_familia(String nom_familia) {
        this.nom_familia = nom_familia;
    }

    /**
     * Estableix la descripció de la família.
     *
     * @param descripcio Descripció de la família.
     */
    public void setDescripcio(String descripcio) {
        this.descripcio = descripcio;
    }

    /**
     * Estableix la data d'alta de la família.
     *
     * @param data_alta_fam Data d'alta de la família.
     */
    public void setData_alta_fam(LocalDate data_alta_fam) {
        this.data_alta_fam = data_alta_fam;
    }

    /**
     * Estableix l'ID del proveïdor associat a la família.
     *
     * @param id_proveidor_fam ID del proveïdor de la família.
     */
    public void setId_proveidor_fam(int id_proveidor_fam) {
        this.id_proveidor_fam = id_proveidor_fam;
    }

    /**
     * Estableix les observacions addicionals sobre la família.
     *
     * @param Observacions Observacions addicionals sobre la família.
     */
    public void setObservacions(String Observacions) {
        this.Observacions = Observacions;
    }

    /**
     * Obtén l'ID de la família.
     *
     * @return ID únic de la família.
     */
    public int getId_fam() {
        return id_fam;
    }

    /**
     * Obtén el nom de la família.
     *
     * @return Nom de la família.
     */
    public String getNom_familia() {
        return nom_familia;
    }

    /**
     * Obtén la descripció de la família.
     *
     * @return Descripció de la família.
     */
    public String getDescripcio() {
        return descripcio;
    }

    /**
     * Obtén la data d'alta de la família.
     *
     * @return Data d'alta de la família.
     */
    public LocalDate getData_alta_fam() {
        return data_alta_fam;
    }

    /**
     * Obtén l'ID del proveïdor associat a la família.
     *
     * @return ID del proveïdor de la família.
     */
    public int getId_proveidor_fam() {
        return id_proveidor_fam;
    }

    /**
     * Obtén les observacions addicionals sobre la família.
     *
     * @return Observacions addicionals de la família.
     */
    public String getObservacions() {
        return Observacions;
    }

    /**
     * Representació en forma de cadena de la instància de Familia.
     *
     * @return Cadena de text amb els valors de tots els atributs de la família.
     */
    @Override
    public String toString() {
        return "Familia{" + "id_fam=" + id_fam + ", nom_familia=" + nom_familia
                + ", descripcio=" + descripcio + ", data_alta_fam="
                + data_alta_fam + ", id_proveidor_fam=" + id_proveidor_fam
                + ", Observacions=" + Observacions + '}';
    }

}
