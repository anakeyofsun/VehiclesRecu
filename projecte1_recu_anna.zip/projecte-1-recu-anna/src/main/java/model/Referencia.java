/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.time.LocalDate;

/**
 * Classe que representa una referència de producte al sistema. Conté informació
 * detallada sobre el producte, com el seu nom, quantitat, unitat de mesura,
 * dates d'alta i fabricació, descripció, preu, unitats venudes, i associacions
 * amb una família i proveïdor específics.
 *
 * @autor mayoa
 */
public class Referencia {

    private int id;
    private String nom;
    private int quantitat;
    private String unitat_mida;
    private LocalDate data_alta;
    private String data_fabricacio;
    private String descripcio;
    private String preu;
    private int unitats_venudes;
    private int id_fam;
    private int id_proveidor;

    /**
     * Constructor buit de la classe Referencia. Inicialitza una referència de
     * producte sense dades específiques.
     */
    public Referencia() {
    }

    /**
     * Obté l'ID únic de la referència.
     *
     * @return ID de la referència.
     */
    public int getId() {
        return id;
    }

    /**
     * Estableix l'ID únic de la referència.
     *
     * @param id ID de la referència.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Obté el nom de la referència.
     *
     * @return Nom de la referència.
     */
    public String getNom() {
        return nom;
    }

    /**
     * Estableix el nom de la referència.
     *
     * @param nom Nom de la referència.
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Obté la quantitat disponible de la referència.
     *
     * @return Quantitat de la referència.
     */
    public int getQuantitat() {
        return quantitat;
    }

    /**
     * Estableix la quantitat disponible de la referència.
     *
     * @param quantitat Quantitat de la referència.
     */
    public void setQuantitat(int quantitat) {
        this.quantitat = quantitat;
    }

    /**
     * Obté la unitat de mesura de la referència.
     *
     * @return Unitat de mesura de la referència.
     */
    public String getUnitat_mida() {
        return unitat_mida;
    }

    /**
     * Estableix la unitat de mesura de la referència.
     *
     * @param unitat_mida Unitat de mesura de la referència.
     */
    public void setUnitat_mida(String unitat_mida) {
        this.unitat_mida = unitat_mida;
    }

    /**
     * Obté la data d'alta de la referència.
     *
     * @return Data d'alta de la referència.
     */
    public LocalDate getData_alta() {

        return data_alta;
    }

    /**
     * Estableix la data d'alta de la referència.
     *
     * @param data_alta Data d'alta de la referència.
     */
    public void setData_alta(LocalDate data_alta) {
        this.data_alta = data_alta;
    }

    /**
     * Obté la data de fabricació de la referència.
     *
     * @return Data de fabricació de la referència.
     */
    public String getData_fabricacio() {

        return data_fabricacio;
    }

    /**
     * Estableix la data de fabricació de la referència.
     *
     * @param data_fabricacio Data de fabricació de la referència.
     */
    public void setData_fabricacio(String data_fabricacio) {

        this.data_fabricacio = data_fabricacio;
    }

    /**
     * Obté la descripció de la referència.
     *
     * @return Descripció de la referència.
     */
    public String getDescripcio() {
        return descripcio;
    }

    /**
     * Estableix la descripció de la referència.
     *
     * @param descripcio Descripció de la referència.
     */
    public void setDescripcio(String descripcio) {
        this.descripcio = descripcio;
    }

    /**
     * Obté el preu de la referència.
     *
     * @return Preu de la referència.
     */
    public String getPreu() {

        return preu;
    }

    /**
     * Estableix el preu de la referència.
     *
     * @param preu Preu de la referència.
     */
    public void setPreu(String preu) {

        this.preu = preu;
    }

    /**
     * Obté el nombre d'unitats venudes de la referència.
     *
     * @return Unitats venudes de la referència.
     */
    public int getUnitats_venudes() {
        return unitats_venudes;
    }

    /**
     * Estableix el nombre d'unitats venudes de la referència.
     *
     * @param unitats_venudes Unitats venudes de la referència.
     */
    public void setUnitats_venudes(int unitats_venudes) {
        this.unitats_venudes = unitats_venudes;
    }

    /**
     * Obté l'ID de la família a la qual pertany la referència.
     *
     * @return ID de la família de la referència.
     */
    public int getId_fam() {
        return id_fam;
    }

    /**
     * Estableix l'ID de la família a la qual pertany la referència.
     *
     * @param id_fam ID de la família de la referència.
     */
    public void setId_fam(int id_fam) {
        this.id_fam = id_fam;
    }

    /**
     * Obté l'ID del proveïdor associat a la referència.
     *
     * @return ID del proveïdor de la referència.
     */
    public int getId_proveidor() {
        return id_proveidor;
    }

    /**
     * Estableix l'ID del proveïdor associat a la referència.
     *
     * @param id_proveidor ID del proveïdor de la referència.
     */
    public void setId_proveidor(int id_proveidor) {
        this.id_proveidor = id_proveidor;
    }

    /**
     * Representació en forma de cadena de la instància de Referencia.
     *
     * @return Cadena amb la informació completa de la referència.
     */
    @Override
    public String toString() {
        return "Id: " + id + " ; nom: " + nom + " ; Id familia: " + id_fam + " ; ID proveïdor: " + id_proveidor
                + "; data de fabricacio: " + data_fabricacio + " ; data d'alta: " + data_alta
                + " ; preu: " + preu + " ; quantitat: " + quantitat + " ; unitats venudes: " + unitats_venudes
                + " ; descripcio: " + descripcio + " ; unitat de mida: " + unitat_mida;
    }
}
