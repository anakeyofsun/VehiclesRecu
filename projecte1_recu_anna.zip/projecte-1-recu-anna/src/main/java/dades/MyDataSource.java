/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dades;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Classe que gestiona el pool de connexions a la base de dades utilitzant
 * HikariCP.
 *
 * Aquesta classe proporciona una connexió única al pool i ofereix una forma
 * eficient i reutilitzable de gestionar les connexions per a la base de dades
 * del projecte.
 *
 * Inclou un mètode públic per obtenir connexions i un altre per tancar el pool
 * de connexions.
 */
public class MyDataSource {

    /**
     * Objecte de configuració per al pool de connexions. Té dues referències
     * privades i estàtiques perquè només hi puguem accedir des de dins
     * d'aquesta classe.
     */
    private static final HikariConfig config = new HikariConfig(); // objecte que ens permetrà configurar el pool

    /**
     * Pool de connexions a la base de dades gestionat per HikariCP.
     */
    private static HikariDataSource dataSource; //és el pool de connexions

    //per poder inicialitzar els dos objectes privats ABANS que es cridi el únic mètode públic getConnection
    static {
        config.setJdbcUrl("jdbc:mysql://localhost/projecte1db?useUnicode=true&serverTimezone=Europe/Madrid&allowPublicKeyRetrieval=true&useSSL=false");
        config.setUsername("root");
        config.setPassword("123456");
        config.addDataSourceProperty("maximumPoolSize", 1); //al pool només tindrem 1 connexió
        //altres propietats indicades a https://github.com/brettwooldridge/HikariCP#rocket-initialization
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        dataSource = new HikariDataSource(config); //ja tenim el pool de connexions
    }

    /**
     * Constructor amb paràmetres (no utilitzat en aquest cas).
     *
     * @param projecte1db Nom de la base de dades.
     * @param root Nom d'usuari.
     * @param jv Altres configuracions.
     */
    public MyDataSource(String projecte1db, String root, String jv) {
    }

    /**
     * Retorna una connexió disponible del pool de connexions.
     *
     * @return Una connexió a la base de dades.
     * @throws SQLException Si es produeix un error al obtenir la connexió.
     */
    public static Connection getConnection() throws SQLException {
        //retornarà una connexió disponible del pool de connexions
        return dataSource.getConnection();
    }

    /**
     * Tanca el pool de connexions si està inicialitzat.
     *
     * Aquest mètode s'ha de cridar abans de finalitzar l'aplicació per
     * alliberar recursos.
     */
    public static void close() {
        if (dataSource != null) {
            dataSource.close();
        }
    }

}
