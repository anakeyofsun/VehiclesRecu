/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dades;

import java.sql.SQLException;
import java.util.List;

/**
 * Interfície genèrica per a definir operacions bàsiques d'accés a dades.
 *
 * @param <T> El tipus d'objecte que serà gestionat per la implementació de la
 * interfície.
 * @author Anna
 */
public interface DAOInterfacegetAll<T> {

    /**
     * Recupera una llista amb tots els elements de tipus {@code T}
     * emmagatzemats.
     *
     * @return Una llista que conté tots els elements de tipus {@code T}.
     * @throws SQLException Si es produeix un error en accedir a la base de
     * dades.
     */
    public List<T> getAll() throws SQLException;

}
