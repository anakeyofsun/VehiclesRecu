/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dades;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.Familia;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe que implementa l'accés a la base de dades per a la gestió de la taula
 * Families.
 *
 * @author oriol
 */
public class FamiliaDAO implements DAOInterface<Familia>, DAOInterfacegetAll<Familia> {

    /**
     * Constructor de la classe FamiliaDAO.
     *
     * @throws SQLException Si es produeix un error al establir la connexió
     * inicial amb la base de dades.
     */
    public FamiliaDAO() throws SQLException {
        super();
    }

    /**
     * Recupera totes les famílies emmagatzemades a la base de dades.
     *
     * @return Una llista de totes les famílies disponibles a la base de dades.
     * @throws SQLException Si es produeix un error en executar la consulta SQL.
     */
    @Override
    public List<Familia> getAll() throws SQLException {

        List<Familia> famlist = new ArrayList<>();

        String sentenciaSql = "select * from Families ";
        Connection conn = null;
        try {
            conn = MyDataSource.getConnection();
            PreparedStatement pstm = conn.prepareStatement(sentenciaSql);

            {
                ResultSet rs = pstm.executeQuery();
                //Mostrar dades
                while (rs.next()) {
                    Familia f = new Familia();
                    f.setId_fam(rs.getInt("id_familia"));
                    f.setNom_familia(rs.getString("nom_familia"));
                    f.setDescripcio(rs.getString("descripcio"));
                    f.setData_alta_fam(rs.getDate("data_alta").toLocalDate());
                    f.setId_proveidor_fam(rs.getInt("id_proveidor_defecte"));
                    f.setObservacions(rs.getString("observacions"));

                    famlist.add(f);

                }
            }
            return famlist;
        } finally {
            conn.close();
        }

    }

    /**
     * Comprova si un proveïdor amb un identificador específic existeix a la
     * base de dades.
     *
     * @param idProveidor Identificador del proveïdor.
     * @return true si el proveïdor existeix, false en cas contrari.
     */
    public boolean proveidorExiste(int idProveidor) {
        String sql = "SELECT COUNT(*) FROM proveidors WHERE id_proveidor = ?";

        try (PreparedStatement preparedStatement = MyDataSource.getConnection().prepareStatement(sql)) {
            preparedStatement.setInt(1, idProveidor);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0; // Retorna true si hay al menos un proveedor con ese ID
            }
        } catch (SQLException e) {
            System.out.println("Hi ha hagut un error amb la connexió de la BBDD.");
        }

        return false; // Retorna false si hay algún problema o el proveedor no existe
    }

     /**
     * Insereix una nova família a la base de dades.
     * 
     * @param t L'objecte Familia que es vol inserir.
     */
    @Override
    public void insert(Familia t) {
        String insert = "INSERT INTO Families (nom_familia, descripcio, data_alta, "
                + "id_proveidor_defecte, observacions) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = MyDataSource.getConnection().prepareStatement(insert)) {
            pstmt.setString(1, t.getNom_familia());
            pstmt.setString(2, t.getDescripcio());
            pstmt.setDate(3, java.sql.Date.valueOf(t.getData_alta_fam().now()));
            pstmt.setInt(4, t.getId_proveidor_fam());
            pstmt.setString(5, t.getObservacions());

            //executa el insert
            pstmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error al insertar la familia: " + e.getMessage());
        }
    }

    /**
     * Actualitza una família existent a la base de dades.
     * 
     * @param t L'objecte Familia amb les dades actualitzades.
     */
    @Override
    public void update(Familia t) {

        String update = "UPDATE Families SET nom_familia = ?, descripcio = ?, data_alta = ?, "
                + "id_proveidor_defecte = ?, observacions = ? WHERE id_familia = ?";
        try (PreparedStatement pstmt = MyDataSource.getConnection().prepareStatement(update)) {
            pstmt.setString(1, t.getNom_familia());
            pstmt.setString(2, t.getDescripcio());
            pstmt.setDate(3, java.sql.Date.valueOf(t.getData_alta_fam()));
            pstmt.setInt(4, t.getId_proveidor_fam());
            pstmt.setString(5, t.getObservacions());
            pstmt.setInt(6, t.getId_fam());

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Familia actualitzada");
            } else {
                System.out.println("no sha trobat cap familia amb el id obtingut");
            }
        } catch (SQLException e) {
            System.out.println("Error al borrar la familia: " + e.getMessage());
        }
    }

    /**
     * Elimina una família de la base de dades.
     * 
     * @param t L'objecte Familia que es vol eliminar.
     */
    @Override
    public void delete(Familia t) {
        String delete = "DELETE FROM Families WHERE id_familia = ?";
        try (PreparedStatement pstmt = MyDataSource.getConnection().prepareStatement(delete)) {
            pstmt.setInt(1, t.getId_fam());

            int columnesEliminades = pstmt.executeUpdate();
            if (columnesEliminades > 0) {
                System.out.println("La familia s'ha eliminat correctament");
            } else {
                System.out.println("No s'ha trobat cap familia amb aquest ID");
            }

        } catch (SQLException e) {
            System.out.println("Error a l'esborrar la familia: " + e.getMessage());
        }

    }

    /**
     * Recupera una família específica de la base de dades.
     * 
     * @param t L'objecte Familia que conté l'identificador de la família a recuperar.
     * @return La família trobada, o null} si no existeix.
     */
    @Override
    public Familia get(Familia t) {
        String select = "SELECT * FROM Families WHERE id_familia = ?";
        Familia f = null;
        try (PreparedStatement pstmt = MyDataSource.getConnection().prepareStatement(select)) {

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    f = new Familia();
                    f.setId_fam(rs.getInt("id_familia"));
                    f.setNom_familia(rs.getNString("nom_familia"));
                    f.setDescripcio(rs.getString("descripcio"));
                    f.setData_alta_fam(rs.getDate("data_alta").toLocalDate());
                    f.setId_proveidor_fam(rs.getInt("id_proveidor_defecte"));
                    f.setObservacions(rs.getString("observacions"));
                }
            }
        } catch (SQLException e) {
            System.out.println("Error a l'obtenir la familia: " + e.getMessage());
        }
        return f;
    }

}
