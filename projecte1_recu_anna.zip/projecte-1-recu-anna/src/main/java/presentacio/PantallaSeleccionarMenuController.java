/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package presentacio;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import static logica.Mensajes.mostrarMensajeError;

/**
 * Controlador FXML per a la pantalla de selecció de menú. Gestiona la navegació
 * cap a altres seccions de l'aplicació com Proveïdor, Referència, i Família.
 * Implementa la interfície Initializable.
 *
 * @autor mayoa
 */
public class PantallaSeleccionarMenuController implements Initializable {

    @FXML
    private Button btnProveidor;
    @FXML
    private Button btnReferencia;
    @FXML
    private Button btnFamilia1;

    private String rol;
    private PantallaReferenciaController r;

    /**
     * Inicialitza el controlador de la classe.
     *
     * @param url ubicació per inicialitzar, o null si no s'utilitza.
     * @param rb recursos per a internacionalització, o null si no s'utilitza.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

    // Mètode per establir el rol
    public void setRol(String rol) {
        this.rol = rol; // Almacena el rol recibido
    }

    /**
     * Obre la pantalla de Proveïdor quan es fa clic al botó corresponent.
     * Carrega i mostra la vista de la pantalla de Proveïdor en una nova
     * finestra.
     *
     * @param event esdeveniment d'acció associat al botó btnProveidor.
     */
    @FXML
    private void AbrirProveidor(ActionEvent event) {
        try {
            // Cargo la vista
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/pantallaProveidor.fxml"));

            // Cargo el padre
            Parent root = loader.load();

            pantallaProveidorController controllerProveidor = loader.getController();
            controllerProveidor.setRol(this.rol);
            // Creo la scene y el stage
            Scene scene = new Scene(root);
            Stage stage = new Stage();

            // Asocio el stage con el scene
            stage.setScene(scene);
            
            stage.setMinWidth(800);
            stage.setMinHeight(600);
            
            stage.show();

        } catch (Exception e) {
            // Si ocurre un error, muestra el mensaje de error en lugar de solo registrarlo
            mostrarMensajeError(e.getMessage());
        }
    }

    /**
     * Obre la pantalla de Referència quan es fa clic al botó corresponent.
     * Carrega i mostra la vista de la pantalla de Referències en una nova
     * finestra.
     *
     * @param event esdeveniment d'acció associat al botó btnReferencia.
     */
    @FXML
    private void AbrirReferencia(ActionEvent event) {
        try {
            // Cargo la vista
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/PantallaReferencias.fxml"));

            // Cargo el padre
            Parent root = loader.load();
            PantallaReferenciaController controllerReferencia = loader.getController();
            controllerReferencia.setRol(this.rol);

            // Creo la scene y el stage
            Scene scene = new Scene(root);
            Stage stage = new Stage();

            // Asocio el stage con el scene
            stage.setScene(scene);
            
            stage.setMinWidth(800);
            stage.setMinHeight(600);
            
            stage.show();

        } catch (Exception e) {
            // Si ocurre un error, muestra el mensaje de error en lugar de solo registrarlo
            mostrarMensajeError(e.getMessage());
        }
    }

    /**
     * Obre la finestra de la pantalla de família en rebre un esdeveniment
     * d'acció.
     *
     * Aquest mètode s'executa en activar l'esdeveniment d'acció associat, com
     * un clic en un botó. Carrega la vista de la pantalla de família, estableix
     * el rol de l'usuari en el controlador de la nova pantalla i mostra la
     * finestra corresponent.
     *
     * @param event L'esdeveniment d'acció que activa aquest mètode, generalment
     * un clic en un botó.
     */
    @FXML
    private void AbrirFamilia(ActionEvent event) {
        try {
            // Cargo la vista
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/PantallaFamilia.fxml"));

            // Cargo el padre
            Parent root = loader.load();
            pantallaFamiliaController controllerFamilia = loader.getController();
            controllerFamilia.setRol(this.rol);
            // Creo la scene y el stage
            Scene scene = new Scene(root);
            Stage stage = new Stage();

            // Asocio el stage con el scene
            stage.setScene(scene);
            
            stage.setMinWidth(800);
            stage.setMinHeight(600);
            
            stage.show();

        } catch (Exception e) {
            // Si ocurre un error, muestra el mensaje de error en lugar de solo registrarlo
            mostrarMensajeError(e.getMessage());
        }
    }

}
