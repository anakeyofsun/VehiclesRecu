/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package presentacio;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import logica.Autenticacio;
import logica.Excepciones;
import logica.Mensajes;

/**
 * Controlador per a la interfície d'autenticació d'usuari. La classe
 * PantallaAutenticacioController gestiona la lògica d'autenticació d'usuari i
 * la transició a la següent pantalla en cas d'autenticació correcta. Extén la
 * classe Mensajes per mostrar missatges d'informació i d'error. Implementa
 * Initializable per inicialitzar els components de la interfície.
 *
 * @autor chris
 */
public class PantallaAutenticacioController extends Mensajes implements Initializable {

    /**
     * Mètode d'inicialització per configurar qualsevol lògica o dades
     * necessàries en el moment de carregar la interfície. Actualment sense
     * implementació.
     *
     * @param url la URL de la interfície carregada.
     * @param rb el recurs de localització per a la internacionalització.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

    private Autenticacio autenticacio = new Autenticacio();

    @FXML
    private TextField txtUsuari;

    @FXML
    private TextField txtRol;

    @FXML
    private Button btnIniciarSessio;

    /**
     * Gestiona l'esdeveniment d'autenticació de l'usuari quan es prem el botó
     * "Iniciar Sessió". Verifica si l'usuari i el rol introduïts són correctes
     * i, en cas afirmatiu, mostra un missatge d'èxit i obre una nova pantalla.
     * En cas contrari, mostra un missatge d'error.
     *
     * @param event l'esdeveniment d'acció que desencadena l'inici de sessió.
     */
    @FXML
    void iniciarSessio(ActionEvent event) throws Exception {
        String usuario = txtUsuari.getText();
        String rol = txtRol.getText();

        // Verificar autenticación
        if (autenticacio.verificarUsuario(usuario, rol)) {
            // Abrir la nueva pantalla si la autenticación es correcta
            mostrarMensaje("Usuari verificat correctament.");
            try {
                abrirNuevaPantalla(txtRol.getText());
                // Cerrar la pantalla de autenticación
                ((Stage) txtUsuari.getScene().getWindow()).close();
            } catch (IOException e) {
                // Manejo de la excepción si ocurre al abrir la nueva pantalla
                mostrarMensajeError(e.getMessage());
            }
        } else {
            // Mostrar mensaje de error
            mostrarMensajeError("Usuari o rol incorrecte.");
        }
    }

    /**
     * Carrega i obre una nova pantalla de selecció de menús després d'una
     * autenticació exitosa. Si es produeix un error durant la càrrega, es
     * registra i mostra un missatge d'error al registre.
     */
    @FXML
    void abrirNuevaPantalla(String rol) throws Exception {
        try {
            // Cargo la vista
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/PantallaSeleccionaMenus.fxml"));

            // Cargo el padre
            Parent root = loader.load();

            PantallaSeleccionarMenuController controller = loader.getController();
            controller.setRol(rol);  // Pasar el rol al controlador de seleccionar menú
            // Creo la scene y el stage
            Scene scene = new Scene(root);
            Stage stage = new Stage();

            // Asocio el stage con el scene
            stage.setScene(scene);
            
            stage.setMinWidth(600);
            stage.setMinHeight(400);
            
            stage.show();

        } catch (IOException ex) {
            Excepciones.Autenticacion(ex.getMessage());
        }
    }

}
