/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package presentacio;

import model.Referencia;
import dades.ReferenciaDAO;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import logica.Mensajes;
import logica.ReferenciaLogica;

/**
 * Controlador de la interfície gràfica per gestionar les referències en una
 * base de dades. Proporciona funcionalitats per afegir, modificar, eliminar i
 * seleccionar referències. Estén la classe Missatges per mostrar missatges
 * informatius i d'error, i implementa Initializable per la configuració inicial
 * de la interfície.
 *
 * @author mayoa
 */
public class PantallaReferenciaController extends Mensajes implements Initializable {

    @FXML
    private Label Descripcio;

    @FXML
    private Button btnEliminarReferencia;

    @FXML
    private Button btnModificarReferencia;

    @FXML
    private Button btnNovaReferencia;

    @FXML
    private Button btnSalir;

    @FXML
    private TableColumn<Referencia, Integer> cantidad;

    @FXML
    private TableColumn<Referencia, Date> dataAlta;

    @FXML
    private TableColumn<Referencia, Date> dataFab;

    @FXML
    private TableColumn<Referencia, String> descripcio;

    @FXML
    private TableColumn<Referencia, Integer> idFam;

    @FXML
    private TableColumn<Referencia, Integer> idProv;

    @FXML
    private TableColumn<Referencia, Integer> idReferencia;

    @FXML
    private TableColumn<Referencia, String> nombre;

    @FXML
    private TableColumn<Referencia, Float> preu;

    @FXML
    private TableView<Referencia> tblReferencia;

    @FXML
    private TextArea txtAreaDescripcio;

    @FXML
    private TextField txtDataAlta;

    @FXML
    private TextField txtDataFabricacio;

    @FXML
    private TextField txtIdFamilia;

    @FXML
    private TextField txtIdProveidor;

    @FXML
    private TextField txtNom;

    @FXML
    private TextField txtPreu;

    @FXML
    private TextField txtReferencia;

    @FXML
    private TextField txtCantidad;

    @FXML
    private TextField txtUnitatMida;

    @FXML
    private TextField txtUnitatVenudes;

    @FXML
    private Button btn_filtrarRef;

    @FXML
    private TextField tf_filtrarRef;

    @FXML
    private TableColumn<Referencia, Integer> unitVen;

    @FXML
    private TableColumn<Referencia, String> unitatMida;

    private ReferenciaDAO referenciaDAO;

    private ReferenciaLogica referenciaLogica;
    private String rol;

    private int idFamilia;

    public int getIdFamilia() {
        return idFamilia;
    }

    public void setIdFamilia(int idFamilia) {
        this.idFamilia = idFamilia;
    }

    /**
     * Inicialitza la classe del controlador configurant la lògica de negoci, el
     * model de dades i la visualització de la taula de referències. Estableix
     * la configuració de les columnes de la taula i afegeix un listener per
     * actualitzar els camps de text amb les dades de la referència
     * seleccionada.
     *
     * @param url la URL de la ubicació dels recursos.
     * @param rb el conjunt de recursos per localització.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        setIdFamilia(0);
        try {
            this.referenciaLogica = new ReferenciaLogica();
            referenciaLogica.carregarReferencia(idFamilia);
        } catch (SQLException ex) {
            Logger.getLogger(PantallaReferenciaController.class.getName()).log(Level.SEVERE, null, ex);
        }

        this.idReferencia.setCellValueFactory(new PropertyValueFactory<>("id"));
        this.nombre.setCellValueFactory(new PropertyValueFactory<>("nom"));
        this.cantidad.setCellValueFactory(new PropertyValueFactory<>("quantitat"));
        this.unitatMida.setCellValueFactory(new PropertyValueFactory<>("unitat_mida"));
        this.dataAlta.setCellValueFactory(new PropertyValueFactory<>("data_alta"));
        this.dataFab.setCellValueFactory(new PropertyValueFactory<>("data_fabricacio"));
        this.descripcio.setCellValueFactory(new PropertyValueFactory<>("descripcio"));
        this.preu.setCellValueFactory(new PropertyValueFactory<>("preu"));
        this.unitVen.setCellValueFactory(new PropertyValueFactory<>("unitats_venudes"));
        this.idFam.setCellValueFactory(new PropertyValueFactory<>("id_fam"));
        this.idProv.setCellValueFactory(new PropertyValueFactory<>("id_proveidor"));

        // Obtener la lista de referencias desde ReferenciaDAO
        this.tblReferencia.setItems(referenciaLogica.getListObservableReferencia());

        // Añadir el listener a la tabla para que se actualicen los TextFields cuando cambie la selección
        tblReferencia.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                // Actualizar los TextFields con la información del elemento seleccionado

                txtNom.setText(newSelection.getNom());
                txtReferencia.setText(String.valueOf(newSelection.getId()));
                txtCantidad.setText(String.valueOf(newSelection.getQuantitat()));
                txtUnitatMida.setText(newSelection.getUnitat_mida());
                txtDataAlta.setText(newSelection.getData_alta().toString());
                txtDataFabricacio.setText(newSelection.getData_fabricacio());
                txtAreaDescripcio.setText(newSelection.getDescripcio());
                txtPreu.setText(String.valueOf(newSelection.getPreu()));
                txtUnitatVenudes.setText(String.valueOf(newSelection.getUnitats_venudes()));
                txtIdFamilia.setText(String.valueOf(newSelection.getId_fam()));
                txtIdProveidor.setText(String.valueOf(newSelection.getId_proveidor()));
            }
            configurarBotonesPorRol();
        });

    }

    /**
     * Estableix el rol de l'usuari actual i configura els botons de la
     * interfície en funció del rol especificat.
     *
     * @param rol El rol de l'usuari actual (per exemple, "Administrador",
     * "Venedor").
     */
    public void setRol(String rol) {
        this.rol = rol;
        configurarBotonesPorRol(); // Llamar para aplicar la configuración de botones al establecer el rol
    }

    /**
     * Configura la disponibilitat dels botons de la interfície segons el rol de
     * l'usuari. Si el rol és "Venedor", alguns botons d'administració es
     * deshabiliten per limitar la funcionalitat disponible.
     */
    private void configurarBotonesPorRol() {
        if (rol != null) {
            if (rol.equals("Venedor")) {
                // Deshabilitar botones para usuarios regulares
                btnNovaReferencia.setDisable(true);
                btnModificarReferencia.setDisable(true);
                btnEliminarReferencia.setDisable(true);
            }
        }
    }

    /**
     * Obre la interfície per afegir una nova referència. Aquest mètode
     * configura una nova finestra on es pot crear una nova referència, i passa
     * la referència de la taula i llista observable al nou controlador.
     *
     * @param event l'esdeveniment d'acció que dispara la creació d'una nova
     * referència.
     */
    @FXML
    void Afegir(ActionEvent event) {
        try {
            // Cargo la vista
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/PantallaInsertReferencia.fxml"));

            // Cargo el padre
            Parent root = loader.load();

            // Obtengo el controlador de la nueva ventana
            PantallaInsertReferenciaController controladorInsert = loader.getController();

            // Paso la referencia de la tabla y de la lista observable al controlador de la nueva ventana
            controladorInsert.setReferenciaController(this);
            // Creo la scene y el stage
            Scene scene = new Scene(root);
            Stage stage = new Stage();

            // Asocio el stage con el scene
            stage.setScene(scene);
            stage.show();

        } catch (IOException ex) {
            Logger.getLogger(PantallaSeleccionarMenuController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Afegix una nova referència a la taula visualitzant directament a la
     * interfície.
     *
     * @param nuevaReferencia la nova referència a afegir a la taula.
     */
    public void actualizarTablaConNuevaReferencia(Referencia nuevaReferencia) {
    
        tblReferencia.getItems().add(nuevaReferencia);       

        tblReferencia.refresh();  // Refrescar la tabla para que se vea la nueva entrada
    }

    /**
     * Elimina la referència seleccionada a la taula. Si no hi ha cap referència
     * seleccionada, es mostra un missatge d'error.
     *
     * @param event l'esdeveniment d'acció que dispara l'eliminació de la
     * referència.
     */
    @FXML
    void Eliminar(ActionEvent event) throws SQLException {

        //Primer seleccionem la referència a esborrar.
        Referencia referenciaSeleccionada = tblReferencia.getSelectionModel().getSelectedItem();

        if (referenciaSeleccionada == null) {
            // Mostrar missatge d'error si no s'ha seleccionat cap referència
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Selecció requerida");
            alert.setHeaderText(null);
            alert.setContentText("Selecciona una referència per poder-la esborrar");
            alert.showAndWait();
            return;
        }

        // Demanem confirmació per a esborrar la referència. 
        Alert alertConfirmacio = new Alert(Alert.AlertType.CONFIRMATION);
        alertConfirmacio.setTitle("Confirmació d'esborrat");
        alertConfirmacio.setHeaderText(null);
        alertConfirmacio.setContentText("Segur que vols esborrar la referència seleccionada?");
        ReferenciaLogica referenciaLogica = new ReferenciaLogica();

        Optional<ButtonType> resultat = alertConfirmacio.showAndWait();
        if (resultat.isPresent() && resultat.get() == ButtonType.OK) {
            try {

                //Cridem a la capa lògica per a que faci d'intermediària amb el DAO.
                referenciaLogica.eliminarReferencia(referenciaSeleccionada);
                //Actualitzaem la taula una vegada la referència seleccionada ha estat esborrada.
                tblReferencia.refresh();

            } catch (SQLException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    /**
     * Modifica les dades de la referència seleccionada a la taula segons els
     * valors introduïts als camps de text.
     *
     * @param event l'esdeveniment d'acció que dispara la modificació de la
     * referència.
     * @throws SQLException si ocorre un error en intentar actualitzar la
     * referència a la base de dades.
     * @throws Exception si es produeix qualsevol altre error durant la
     * modificació.
     */
    @FXML
    void Modificar(ActionEvent event) throws SQLException, Exception {
        Referencia referenciaSeleccionada = tblReferencia.getSelectionModel().getSelectedItem();
        if (referenciaSeleccionada != null) {
            referenciaSeleccionada.setNom(txtNom.getText());
            referenciaSeleccionada.setQuantitat(Integer.parseInt(txtCantidad.getText()));
            referenciaSeleccionada.setUnitat_mida(txtUnitatMida.getText());
            referenciaSeleccionada.setData_alta(Date.valueOf(txtDataAlta.getText()).toLocalDate());  // Asegúrate de que esté en formato correcto
            referenciaSeleccionada.setData_fabricacio(txtDataFabricacio.getText());
            referenciaSeleccionada.setDescripcio(txtAreaDescripcio.getText());
            referenciaSeleccionada.setPreu(txtPreu.getText());
            referenciaSeleccionada.setUnitats_venudes(Integer.parseInt(txtUnitatVenudes.getText()));
            referenciaSeleccionada.setId_fam(Integer.parseInt(txtIdFamilia.getText()));
            referenciaSeleccionada.setId_proveidor(Integer.parseInt(txtIdProveidor.getText()));

            // Actualizar la tabla visualmente
            tblReferencia.refresh();
            referenciaLogica.modificarReferencia(referenciaSeleccionada);
        } else {
            mostrarMensajeError("No s'ha seleccionat cap referència.");
        }

    }

    /**
     * Tanca la finestra actual i torna a la pantalla anterior sense tancar el
     * programa.
     *
     * @param event l'esdeveniment d'acció que dispara l'acció de tornar enrere.
     */
    @FXML
    void VolverAtras(ActionEvent event) {
        Stage stage = (Stage) this.btnSalir.getScene().getWindow();
        stage.close();
    }

    /**
     * Filtra les referències per família segons el valor introduït al camp de
     * text. Si el valor no és un nombre enter vàlid, es mostra un missatge
     * d'error.
     *
     * @param event l'esdeveniment d'acció que dispara l'acció de filtratge.
     */
    @FXML
    void FiltrarPerFamilia(ActionEvent event) {

        try {
            setIdFamilia(Integer.parseInt(tf_filtrarRef.getText()));
            buidarCamps();
            referenciaLogica.getListObservableReferencia().clear();
            referenciaLogica.carregarReferencia(idFamilia);
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error de filtre");
            alert.setHeaderText(null);
            alert.setContentText("Has de filtrar per un nombre enter.");
            alert.showAndWait();
        }
    }

    /**
     * Buida tots els camps de text de la interfície.
     */
    private void buidarCamps() {
        txtReferencia.clear();
        txtNom.clear();
        txtCantidad.clear();
        txtUnitatMida.clear();
        txtDataAlta.clear();
        txtDataFabricacio.clear();
        txtPreu.clear();
        txtUnitatVenudes.clear();
        txtIdFamilia.clear();
        txtIdProveidor.clear();
        txtAreaDescripcio.clear();
    }
}
