package presentacio;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import static javafx.application.Application.launch;
import javafx.scene.layout.Pane;

/**
 * Classe principal de l'aplicació JavaFX que inicialitza i mostra la interfície
 * d'usuari. Extén la classe {@link Application} i defineix el mètode `start`
 * per carregar i mostrar la finestra principal.
 *
 * @autor chris
 */
public class App extends Application {

    /**
     * Mètode d'inici de l'aplicació JavaFX. Carrega el fitxer FXML corresponent
     * i estableix l'escena a la finestra principal.
     *
     * @param stage L'escenari principal de l'aplicació.
     * @throws IOException Si es produeix un error en carregar el fitxer FXML.
     */
    @Override
    public void start(Stage stage) throws IOException {
        try {

            //Cargo la vista
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(App.class.getResource("/fxml/PantallaAutenticacio.fxml"));

            // Cargo la ventana
            Pane ventana = (Pane) loader.load();

            // Cargo el scene
            Scene scene = new Scene(ventana);

            // Seteo la scene y la muestro
            stage.setScene(scene);

            stage.setMaxWidth(600);
            stage.setMaxHeight(400);
            
            stage.setMinWidth(600);
            stage.setMinHeight(400);
            
            stage.show();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Mètode principal de l'aplicació que llança l'aplicació JavaFX.
     *
     * @param args Arguments de la línia de comandes (no utilitzats).
     */
    public static void main(String[] args) {
        launch();
    }

}
