/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package presentacio;

import model.Familia;
import dades.FamiliaDAO;
import java.sql.SQLException;
import java.util.Optional;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import logica.FamiliaLogic;

/**
 * Controlador per a la pantalla d'inserció d'una nova família. Aquesta classe
 * gestiona la creació de noves famílies i la seva inserció a la base de dades,
 * amb la validació de les dades introduïdes. A més, actualitza la taula de
 * famílies un cop la creació és correcta.
 *
 * @autor oriol
 */
public class PantallaInsertFamiliaController {

    @FXML
    private Button btn_afegir_familia;

    @FXML
    private Button btn_sortir_insfam;

    @FXML
    private TextField data_alta_insfam;

    @FXML
    private TextArea descripcio_insfam;

    @FXML
    private TextField id_proveidor_insfam;

    @FXML
    private TextField nom_familia_insfam;

    @FXML
    private TextArea observacions_insfam;

    private FamiliaDAO familiaDAO;

    private pantallaFamiliaController familiaController;

    /**
     * Configura el controlador de la pantalla de famílies per actualitzar la
     * taula de famílies un cop s'ha afegit una nova.
     *
     * @param controller El controlador de la pantalla de famílies.
     */
    public void setFamiliaController(pantallaFamiliaController controller) {
        this.familiaController = controller;
    }

    /**
     * Insereix una nova família amb les dades proporcionades en els camps de
     * text. Abans de guardar, demana una confirmació a l'usuari. Si la
     * confirmació és afirmativa, es guarda la família i s'actualitza la taula
     * de famílies. Si es produeix un error, es mostra un missatge d'error.
     *
     * @param event L'esdeveniment d'acció que desencadena la creació de la
     * família.
     */
    @FXML
    private void inserirFam(ActionEvent event) {
        try {

            familiaDAO = new FamiliaDAO();
            FamiliaLogic familiaLogic = new FamiliaLogic();

            String nomFamilia = nom_familia_insfam.getText();
            String descripcio = descripcio_insfam.getText();
            //java.sql.Date dataAlta = java.sql.Date.valueOf(data_alta_insfam.getText());
            int idProveidorDef = Integer.parseInt(id_proveidor_insfam.getText());
            String observacions = observacions_insfam.getText();

            //TODO existeix proveidor?
            Familia familiaAfegir = new Familia();
            familiaAfegir.setNom_familia(nomFamilia);
            familiaAfegir.setDescripcio(descripcio);
            //familiaAfegir.setData_alta_fam(dataAlta.toLocalDate());
            familiaAfegir.setId_proveidor_fam(idProveidorDef);
            familiaAfegir.setObservacions(observacions);

            Alert alertConfirmacio = new Alert(Alert.AlertType.CONFIRMATION);
            alertConfirmacio.setTitle("Confirmació");
            alertConfirmacio.setHeaderText("Confirma la creació de la família");
            alertConfirmacio.setContentText("Estàs segur de voler crear la família amb aquestes dades?");

            Optional<ButtonType> resultatConfirmacio = alertConfirmacio.showAndWait();

            // Si  l'usuari confirma, guardem les dades.
            if (resultatConfirmacio.isPresent() && resultatConfirmacio.get() == ButtonType.OK) {
                try {
                    familiaLogic.afegirFamilia(familiaAfegir);

                    //Actualitzem la taula.
                    
                    familiaController.actualizarTaulaFamilia(familiaAfegir);
                    Stage stage = (Stage) btn_afegir_familia.getScene().getWindow();
                    stage.close();

                } catch (Exception e) {
                    Alert alertError = new Alert(Alert.AlertType.ERROR);
                    alertError.setTitle("Error");
                    alertError.setHeaderText("Error en crear la família.");
                    alertError.setContentText("S'ha produït un error en intentar guardar la família." + e.getMessage());
                    alertError.showAndWait();
                }
            }

        } catch (SQLException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Error");
            alert.setContentText("Error en inserir una nova familia");
            alert.showAndWait();

        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Error");
            alert.setContentText("Escriu correctament els valors numèrics");
            alert.showAndWait();
        }
    }

    /**
     * Tanca la finestra de la pantalla d'inserció de família.
     *
     * @param event L'esdeveniment d'acció que tanca la finestra.
     */
    @FXML
    private void sortir(ActionEvent event) {
        Stage stage = (Stage) this.btn_sortir_insfam.getScene().getWindow();
        stage.close();

    }

}
