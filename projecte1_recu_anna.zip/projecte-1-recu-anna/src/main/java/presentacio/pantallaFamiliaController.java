/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package presentacio;

import model.Familia;
import dades.FamiliaDAO;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import logica.FamiliaLogic;

/**
 * Controlador per a la pantalla de Família. Gestiona les operacions com afegir,
 * modificar, eliminar i visualitzar les famílies en la taula.
 *
 * @autor oriol
 */
public class pantallaFamiliaController implements Initializable {

    @FXML
    private Button btn_eliminar;

    @FXML
    private Button btn_modificar;

    @FXML
    private Button btn_nova;

    @FXML
    private Button btn_sortir;

    @FXML
    private Label lb_descripcio;

    @FXML
    private Label lb_observacions;

    @FXML
    private TableColumn<Familia, Date> tc_dataAlta;

    @FXML
    private TableColumn<Familia, String> tc_descripcio;

    @FXML
    private TableColumn<Familia, Integer> tc_id;

    @FXML
    private TableColumn<Familia, Integer> tc_idProveidor;

    @FXML
    private TableColumn<Familia, String> tc_nom;

    @FXML
    private TableColumn<Familia, String> tc_observacions;

    @FXML
    private TableView<Familia> tv_familia;

    @FXML
    private TextArea txt_areaDescripcio;

    @FXML
    private TextArea txt_areaObservacions;

    @FXML
    private TextField txt_dataAlta;

    @FXML
    private TextField txt_id;

    @FXML
    private TextField txt_idProveidor;

    @FXML
    private TextField txt_nom;

    private ObservableList<Familia> families;

    private FamiliaDAO familiaDAO;

    private String rol;

    /**
     * Inicialitza la pantalla carregant les dades de les famílies i configurant
     * els enllaços entre la vista i la lògica de dades.
     *
     * @param url URL per a la càrrega de recursos.
     * @param rb ResourceBundle per a l'idioma.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {
            familiaDAO = new FamiliaDAO();
        } catch (SQLException ex) {
            System.out.println("TODO");
        }
        this.tc_id.setCellValueFactory(new PropertyValueFactory<>("id_fam"));
        this.tc_nom.setCellValueFactory(new PropertyValueFactory<>("nom_familia"));
        this.tc_descripcio.setCellValueFactory(new PropertyValueFactory<>("descripcio"));
        this.tc_dataAlta.setCellValueFactory(new PropertyValueFactory<>("data_alta_fam"));
        this.tc_idProveidor.setCellValueFactory(new PropertyValueFactory<>("id_proveidor_fam"));
        this.tc_observacions.setCellValueFactory(new PropertyValueFactory<>("Observacions"));

        try {
            ObservableList<Familia> itemFam = FXCollections.observableArrayList(familiaDAO.getAll());
            this.tv_familia.setItems(itemFam);
        } catch (SQLException ex) {
            System.out.println("TODO");
        }
        tv_familia.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                txt_id.setText(String.valueOf(newSelection.getId_fam()));
                txt_nom.setText(newSelection.getNom_familia());
                txt_areaDescripcio.setText(newSelection.getDescripcio());
                txt_dataAlta.setText(newSelection.getData_alta_fam().toString());
                txt_idProveidor.setText(String.valueOf(newSelection.getId_proveidor_fam()));
                txt_areaObservacions.setText(newSelection.getObservacions());
            }
        });

    }

    /**
     * Estableix el rol de l'usuari i configura els botons segons aquest rol.
     *
     * @param rol El rol de l'usuari (per exemple, "Venedor").
     */
    public void setRol(String rol) {
        this.rol = rol;
        configurarBotonesPorRol(); // Llamar para aplicar la configuración de botones al establecer el rol
    }

    /**
     * Configura els botons per habilitar-los o deshabilitar-los en funció del
     * rol de l'usuari.
     */
    private void configurarBotonesPorRol() {
        if (rol != null) {
            if (rol.equals("Venedor")) {
                // Deshabilitar botones para usuarios regulares
                btn_nova.setDisable(true);
                btn_eliminar.setDisable(true);
                btn_modificar.setDisable(true);
            }
        }
    }

    /**
     * Obre la finestra per afegir una nova família.
     *
     * @param event L'esdeveniment de clic al botó.
     */
    @FXML
    void afegirFamilia(ActionEvent event) {
        try {
            // Cargo la vista
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/PantallaInsertFamilia.fxml"));

            // Cargo el padre
            Parent root = loader.load();

            // Obtengo el controlador de la nueva ventana
            PantallaInsertFamiliaController controladorInsert = loader.getController();

            // Paso la referencia de la tabla y de la lista observable al controlador de la nueva ventana
            controladorInsert.setFamiliaController(this);
            // Creo la scene y el stage
            Scene scene = new Scene(root);
            Stage stage = new Stage();

            // Asocio el stage con el scene
            stage.setScene(scene);
            stage.show();

        } catch (IOException ex) {
            System.out.println("");
        }
    }

    /**
     * Actualitza la taula amb una nova família afegida.
     *
     * @param novaFamilia La nova família que es vol afegir a la taula.
     */
    public void actualizarTaulaFamilia(Familia novaFamilia) {
        if (novaFamilia.getData_alta_fam() == null) {
            novaFamilia.setData_alta_fam(LocalDate.now()); // Inicialitza la data si no hi és
        }
        tv_familia.getItems().add(novaFamilia);
        tv_familia.refresh();
    }

    /**
     * Elimina una família seleccionada de la taula després de confirmar
     * l'operació.
     *
     * @param event L'esdeveniment de clic al botó d'eliminar.
     * @throws SQLException Si es produeix un error en la consulta a la base de
     * dades.
     */
    @FXML
    void eliminar(ActionEvent event) throws SQLException {
        Familia familiaSeleccionada = tv_familia.getSelectionModel().getSelectedItem();

        if (familiaSeleccionada != null) {

            Alert alertConfirmacio = new Alert(Alert.AlertType.CONFIRMATION);
            alertConfirmacio.setTitle("Confirmació d'esborrat");
            alertConfirmacio.setHeaderText(null);
            alertConfirmacio.setContentText("Segur que vols esborrar la família seleccionada?");
            FamiliaLogic familiaLogic = new FamiliaLogic();

            Optional<ButtonType> resultat = alertConfirmacio.showAndWait();
            if (resultat.isPresent() && resultat.get() == ButtonType.OK) {
                try {
                    //Cridem a la capa lògica per a que faci d'intermediària amb el DAO.
                    familiaLogic.esborrarFamilia(familiaSeleccionada);
                    //Actualitzaem la taula una vegada el proveïdor seleccionat ha estat esborrat.
                    
                    tv_familia.getItems().remove(familiaSeleccionada);
                    //tv_familia.refresh();

                } catch (Exception e) {
                    Alert alertError = new Alert(Alert.AlertType.ERROR);
                    alertError.setTitle("Error");
                    alertError.setHeaderText(null);
                    alertError.setContentText("No es pot esborrar una família amb una referència.");
                    alertError.showAndWait();
                }

            }
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Selecció requerida");
            alert.setHeaderText(null);
            alert.setContentText("Selecciona una família per poder esborrar-la.");
            alert.showAndWait();

        }
    }

    /**
     * Modifica una família seleccionada a la taula després de confirmar
     * l'operació.
     *
     * @param event L'esdeveniment de clic al botó de modificar.
     * @throws SQLException Si es produeix un error en la consulta a la base de
     * dades.
     */
    @FXML
    void modificar(ActionEvent event) throws SQLException {
        Familia familiaSeleccionada = tv_familia.getSelectionModel().getSelectedItem();
        FamiliaLogic familiaLogic = new FamiliaLogic();
        if (familiaSeleccionada != null) {

            familiaSeleccionada.setNom_familia(txt_nom.getText());
            familiaSeleccionada.setDescripcio(txt_areaDescripcio.getText());
            familiaSeleccionada.setData_alta_fam(Date.valueOf(txt_dataAlta.getText()).toLocalDate());
            familiaSeleccionada.setId_proveidor_fam(Integer.parseInt(txt_idProveidor.getText()));
            familiaSeleccionada.setObservacions(txt_areaObservacions.getText());

            Alert alertConfirmacio = new Alert(Alert.AlertType.CONFIRMATION);
            alertConfirmacio.setTitle("Confirmació de modificació");
            alertConfirmacio.setHeaderText(null);
            alertConfirmacio.setContentText("Segur que vols modificar la família seleccionada?");

            Optional<ButtonType> resultatConfirmacio = alertConfirmacio.showAndWait();
            if (resultatConfirmacio.isPresent() && resultatConfirmacio.get() == ButtonType.OK) {
                try {
                    familiaLogic.modificarFamilia(familiaSeleccionada);  // Crida a la capa lògica
                    tv_familia.refresh();  // Refresca la taula amb les dades modificades
                } catch (Exception e) {
                    Alert alertError = new Alert(Alert.AlertType.ERROR);
                    alertError.setTitle("Error");
                    alertError.setHeaderText(null);
                    alertError.setContentText("Hi ha hagut un error en modificar la família.");
                    alertError.showAndWait();
                }
            }
        } else {
            Alert alertError = new Alert(Alert.AlertType.ERROR);
            alertError.setTitle("Error");
            alertError.setHeaderText(null);
            alertError.setContentText("No s'ha seleccionat cap família.");
            alertError.showAndWait();
        }
    }

    /**
     * Tanca la finestra actual quan es clica el botó de sortir.
     *
     * @param event L'esdeveniment de clic al botó de sortir.
     */
    @FXML
    void sortir(ActionEvent event
    ) {
        Stage stage = (Stage) this.btn_sortir.getScene().getWindow();
        stage.close();

    }

}
