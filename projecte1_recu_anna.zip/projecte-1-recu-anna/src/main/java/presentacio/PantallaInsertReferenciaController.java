/*
         * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
         * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package presentacio;

import model.Referencia;
import dades.ReferenciaDAO;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import logica.Mensajes;
import logica.ReferenciaLogica;
import logica.ValidarCamposInsertReferencia;

/**
 * Controlador de la pantalla per inserir referències de producte. Aquesta
 * classe s'encarrega de gestionar la lògica de la interfície d'usuari
 * relacionada amb la inserció de noves referències i la validació de dades.
 * Estén la classe Missatges per utilitzar mètodes de gestió de missatges.
 *
 * @autor mayoa
 */
public class PantallaInsertReferenciaController extends Mensajes implements Initializable {

    private int idFamilia = 0;

    /**
     * Inicialitza el controlador de la classe.
     *
     * @param url URL de localització per al recurs.
     * @param rb Recurs que conté les propietats de la classe.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {
            referenciaLogica = new ReferenciaLogica();
        } catch (SQLException ex) {
            Logger.getLogger(PantallaInsertReferenciaController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private Button btnAfegir;

    @FXML
    private Button btnSortir;

    @FXML
    private TextField txtDataAlta;

    @FXML
    private TextField txtDataFab;

    @FXML
    private TextArea txtDescripcio;

    @FXML
    private TextField txtIdFam;

    @FXML
    private TextField txtIdProv;

    @FXML
    private TextField txtPreu;

    @FXML
    private TextField txtQuantitatReferencia;

    @FXML
    private TextField txtUnitVen;

    @FXML
    private TextField txtUnitatMida;

    @FXML
    private TextField txtnomProducte;

    private ReferenciaDAO referenciaDAO;

    private ReferenciaLogica referenciaLogica;

    private PantallaReferenciaController referenciaController;

    /**
     * Estableix el controlador de la pantalla de referència.
     *
     * @param controller El controlador de la pantalla de referència principal.
     */
    public void setReferenciaController(PantallaReferenciaController controller) {
        this.referenciaController = controller;
    }

    /**
     * Afegeix una nova referència utilitzant les dades del formulari.
     *
     * @param event L'esdeveniment d'acció que desencadena la inserció.
     */
    @FXML
    private void AfegirPersona(ActionEvent event) {
        try {
            // Obtener los datos del formulario
            referenciaDAO = new ReferenciaDAO();
            String nomProducte = txtnomProducte.getText();
            int quantitat = Integer.parseInt(txtQuantitatReferencia.getText());
            String unitatMida = txtUnitatMida.getText().toLowerCase();
            String dataFabricacio = (txtDataFab.getText());
            String descripcioProducte = txtDescripcio.getText();
            String preu = txtPreu.getText();
            int unitatsVenudes = Integer.parseInt(txtUnitVen.getText());
            int idFamilia = Integer.parseInt(txtIdFam.getText());
            int idProveidor = Integer.parseInt(txtIdProv.getText());

            ValidarCamposInsertReferencia.validarDatos(referenciaLogica, referenciaDAO, idFamilia, idProveidor);

            // Crear una instancia de Referencia con los datos del formulario
            Referencia novaReferencia = new Referencia();
            novaReferencia.setNom(nomProducte);
            novaReferencia.setQuantitat(quantitat);
            novaReferencia.setUnitat_mida(unitatMida);

            novaReferencia.setData_fabricacio(dataFabricacio);
            novaReferencia.setDescripcio(descripcioProducte);
            novaReferencia.setPreu(preu);
            novaReferencia.setUnitats_venudes(unitatsVenudes);
            novaReferencia.setId_fam(idFamilia);
            novaReferencia.setId_proveidor(idProveidor);

            //Llamar al método insert() del DAO para insertar la referencia en la base de datos
            referenciaLogica.afegirReferencia(novaReferencia);
            
            // Actualizar la tabla en el controlador principal
            
            referenciaController.actualizarTablaConNuevaReferencia(novaReferencia);

            // Cerrar la ventana de añadir referencia
            Stage stage = (Stage) btnSortir.getScene().getWindow();
            stage.close();
            //Mensaje para saber si se ha hecho el insert
            mostrarMensaje("Referencia inserida correctament.");

        } catch (SQLException e) {
            // Muestra un mensaje de error si hay problemas con la inserción de una nueva referencia
            mostrarMensajeError("Error en inserir la referència: " + e.getMessage());

        } catch (NumberFormatException e) {
            //Comprovar si els camps a on s'han d'introduir numeros siguin correctes com per exemple 
            //(como Quantitat, Preu, etc.)
            mostrarMensajeError("Escriu de forma correcta els numerals: " + e.getMessage());
        } catch (Exception e) {
            // Capturar las excepciones propias (ValidacionException y DatabaseException)
            mostrarMensajeError(e.getMessage());
        }
    }

    /**
     * Tanca la finestra actual sense tancar l'aplicació.
     *
     * @param event L'esdeveniment d'acció que desencadena el tancament de la
     * finestra.
     */
    @FXML
    private void TornarMenu(ActionEvent event) {
        Stage stage = (Stage) this.btnSortir.getScene().getWindow();
        stage.close();

    }

}
