/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

import model.Referencia;
import dades.ReferenciaDAO;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Classe que maneja la lògica de negoci relacionada amb les referències de
 * producte. Aquesta classe actua com a intermediaris entre la capa de dades
 * (ReferenciaDAO) i la interfície d'usuari, permetent realitzar operacions
 * sobre les referències i gestionant una llista observable d'elles.
 *
 * @author chris
 */
public class ReferenciaLogica {

    private ReferenciaDAO referenciaDAO;

    ObservableList<Referencia> llistaObservable;

    /**
     * Constructor per defecte de la classe ReferenciaLogica. Inicialitza la
     * capa de dades i la llista observable de referències, i carrega les
     * referències des de la base de dades.
     *
     * @throws SQLException Si ocorre un error en accedir a la base de dades.
     */
    public ReferenciaLogica() throws SQLException {
        this.referenciaDAO = new ReferenciaDAO();
        this.llistaObservable = FXCollections.observableArrayList();
        //carregarReferencia();
    }

    /**
     * Carrega totes les referències des de la capa de dades i les afegeix a la
     * llista observable.
     *
     * @param idFamilia
     * @throws SQLException Si ocorre un error en accedir a la base de dades.
     */
    public void carregarReferencia(int idFamilia) throws SQLException {
        this.llistaObservable.setAll(referenciaDAO.getAll(idFamilia));
    }

    /**
     * Afegeix una nova referència a la base de dades i a la llista observable.
     *
     * @param referencia La referència que es vol afegir.
     * @throws SQLException Si ocorre un error en accedir a la base de dades.
     */
    public void afegirReferencia(Referencia referencia) throws SQLException, Exception {

        if (!Validacions.validarData(referencia.getData_fabricacio())) {
            throw new Exception("Format de data invàlid. (AAAA-MM-DD)");
        }
        if (!Validacions.validarPreu(referencia.getPreu())) {
            throw new Exception("Format del preu és invàlid. (UU.DD, màxim dos decimals.)");
        }
        
        llistaObservable.add(referencia);
        referenciaDAO.insert(referencia);
        //llistaObservable.add(ref);
    }

    /**
     * Elimina una referència de la base de dades i de la llista observable.
     *
     * @param ref La referència que es vol eliminar.
     * @throws SQLException Si ocorre un error en accedir a la base de dades.
     */
    public void eliminarReferencia(Referencia ref) throws SQLException {
        referenciaDAO.delete(ref);
        llistaObservable.remove(ref);
    }

    /**
     * Modifica una referència existent a la base de dades.
     *
     * @param referencia La referència que es vol modificar.
     * @throws SQLException Si ocorre un error en accedir a la base de dades.
     */
    public void modificarReferencia(Referencia referencia) throws SQLException, Exception {
        if (!Validacions.validarData(referencia.getData_fabricacio())) {
            throw new Exception("Format de data invàlid");
        }
        if (!Validacions.validarPreu(referencia.getPreu())) {
            throw new Exception("Format del preu és invàlid.(UU.DD, màxim dos decimals.)");
        }
        referenciaDAO.update(referencia);
    }

    /**
     * Obtén la llista observable de referències.
     *
     * @return Llista observable de referències.
     */
    public ObservableList<Referencia> getListObservableReferencia() {
        return llistaObservable;
    }

    /**
     * Estableix la llista observable de referències.
     *
     * Aquest mètode permet assignar una nova llista observable de referències a
     * la classe, la qual serà utilitzada per actualitzar la vista de
     * l'interfície d'usuari.
     *
     * @param llistaObservable La nova llista observable de referències.
     */
    public void setLlistaObservable(ObservableList<Referencia> llistaObservable) {
        this.llistaObservable = llistaObservable;
    }

}
