/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

import javafx.scene.control.Alert;

/**
 * Classe utilitària per mostrar missatges d'alerta a la interfície gràfica.
 *
 * Proporciona mètodes estàtics per mostrar missatges d'error i missatges de
 * confirmació a l'usuari mitjançant finestres d'alerta de JavaFX.
 *
 * @author mayoa
 */
public class Mensajes {

    /**
     * Mostra una alerta d'error amb el missatge especificat.
     *
     * @param mensaje El missatge d'error a mostrar a l'alerta.
     */
    public static void mostrarMensajeError(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    /**
     * Mostra una alerta de confirmació amb el missatge especificat.
     *
     * @param mensaje El missatge de confirmació a mostrar a l'alerta.
     */
    public static void mostrarMensaje(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Mensaje ");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();

    }
}
