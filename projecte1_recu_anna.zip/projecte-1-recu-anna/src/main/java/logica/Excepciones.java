/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

/**
 * Aquesta classe proporciona excepcions personalitzades per a diferents tipus
 * d'errors. Cada mètode llença una excepció amb un missatge específic
 * relacionat amb l'error.
 */
public class Excepciones {

    /**
     * Llença una excepció relacionada amb errors de validació.
     *
     * @param mensaje El missatge que descriu l'error de validació.
     * @throws Exception Excepció que conté el missatge d'error.
     */
    public static void ValidacionException(String mensaje) throws Exception {
        throw new Exception("Error de validació: " + mensaje);
    }

    /**
     * Llença una excepció relacionada amb errors a la base de dades.
     *
     * @param mensaje El missatge que descriu l'error de la base de dades.
     * @throws Exception Excepció que conté el missatge d'error.
     */
    public static void DatabaseException(String mensaje) throws Exception {
        throw new Exception("Error en la base de dades: " + mensaje);
    }

    /**
     * Llença una excepció relacionada amb errors en la càrrega d'una pantalla o
     * vista.
     *
     * @param mensaje El missatge que descriu l'error en carregar la pantalla.
     * @throws Exception Excepció que conté el missatge d'error.
     */
    public static void CargaVistaException(String mensaje) throws Exception {
        throw new Exception("Error en carregar la pantalla: " + mensaje);
    }

    /**
     * Llença una excepció relacionada amb errors d'autenticació.
     *
     * @param mensaje El missatge que descriu l'error d'autenticació.
     * @throws Exception Excepció que conté el missatge d'error.
     */
    public static void Autenticacion(String mensaje) throws Exception {
        throw new Exception("Error en carregar la pantalla: " + mensaje);
    }

}
