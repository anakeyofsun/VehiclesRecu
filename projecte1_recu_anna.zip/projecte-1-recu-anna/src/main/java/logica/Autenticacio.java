/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Aquesta classe proporciona funcionalitats per autenticar usuaris i verificar
 * els seus rols. L'autenticació es basa en un fitxer de text amb noms d'usuari
 * i rols associats.
 */
public class Autenticacio extends Mensajes {

    /**
     * Verifica si un usuari amb un rol determinat existeix en un fitxer
     * d'usuaris.
     *
     * @param usuario El nom de l'usuari que es vol verificar.
     * @param rol El rol que es vol verificar per a l'usuari.
     * @return `true` si es troba una coincidència amb l'usuari i el rol en el
     * fitxer, `false` altrament.
     */
    public boolean verificarUsuario(String usuario, String rol) {
        String archivo = "usuaris.txt"; // Ubicación del archivo
        boolean encontrado = false;

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;

            // Leer cada línea del archivo
            while ((linea = br.readLine()) != null) {
                // Separar el nombre del rol usando espacio como separador
                String[] partes = linea.split(" ", 2); // Doble espacio para asegurar separación correcta
                if (partes.length == 2) {
                    String usuarioArchivo = partes[0].trim();
                    String rolArchivo = partes[1].trim();

                    // Comparar usuario y rol
                    if (usuarioArchivo.equalsIgnoreCase(usuario) && rolArchivo.equalsIgnoreCase(rol)) {
                        encontrado = true;
                        break; // Si encuentra coincidencia, termina la búsqueda
                    }
                }
            }
        } catch (IOException e) {
            mostrarMensajeError("Error en llegir l'arxiu: " + e.getMessage());
        }

        return encontrado;
    }
}
