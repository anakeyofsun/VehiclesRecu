/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

import dades.FamiliaDAO;
import java.sql.SQLException;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Familia;

/**
 *
 * @author mayoa
 */
public class FamiliaLogic {

    private FamiliaDAO familiaDAO;
    ObservableList<Familia> llistaObservable;

    /**
     * Constructor que inicialitza el DAO de familia i una llista observable.
     *
     * @throws SQLException si es produeix un error de base de dades en
     * inicialitzar el DAO.
     */
    public FamiliaLogic() throws SQLException {
        this.familiaDAO = new FamiliaDAO();
        this.llistaObservable = FXCollections.observableArrayList();
    }

    /**
     * Esborra un proveïdor proporcionat de la base de dades.
     *
     * @param familia La familia que es vol esborrar.
     * @throws Exception si la familia proporcionada és null o si es produeix un
     * error durant l'operació.
     */
    public void esborrarFamilia(Familia familia) throws Exception {
        if (familia == null) {
            System.out.println("La familia no existeix");
        }
        //Cridem al DAO per esborrar la familia.
        familiaDAO.delete(familia);
    }

    /**
     * Modifica una familia existent a la base de dades després de validar les
     * seves dades.
     *
     * @param familia La familia que es vol modificar amb les noves dades.
     * @throws Exception Si qualsevol de les validacions falla o si es produeix
     * un error en l'actualització.
     */
    public void modificarFamilia(Familia familia) throws Exception {

        familiaDAO.update(familia);
    }

    /**
     * Afegeix una nova familia a la llista observable i a la base de dades
     * després de validar les seves dades.
     *
     * @param familia La familia que es vol afegir.
     * @throws Exception Si qualsevol de les validacions falla o si es produeix
     * un error durant l'operació.
     */
    public void afegirFamilia(Familia familia) throws Exception {

        llistaObservable.add(familia);
        // Inserir la familia al DAO
        familiaDAO.insert(familia);
    }

    /**
     * Retorna una llista amb totes les families emmagatzemades a la base de
     * dades.
     *
     * @return Llista de totes les families.
     * @throws SQLException Si es produeix un error durant la consulta a la base
     * de dades.
     */
    public List<Familia> getAllFamilies() throws SQLException {
        return familiaDAO.getAll();
    }
}
