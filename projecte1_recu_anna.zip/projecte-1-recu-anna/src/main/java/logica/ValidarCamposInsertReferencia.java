/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

import dades.ReferenciaDAO;

/**
 * Classe encarregada de validar els camps necessaris per a la inserció de
 * referències. Realitza verificacions de format i existència a la base de dades
 * per assegurar la validesa de les dades introduïdes.
 *
 * @author mayoa
 *
 */
public class ValidarCamposInsertReferencia extends Mensajes {

    /**
     * Valida les dades proporcionades per a la inserció d'una referència.
     * Verifica el format dels camps, així com l'existència de la família i del
     * proveïdor a la base de dades.
     *
     * @param referenciaLogica Instància de {@link ReferenciaLogica} per
     * realitzar les validacions de lògica de negoci.
     * @param referenciaDAO Instància de {@link ReferenciaDAO} per realitzar les
     * validacions a la base de dades.
     * @param idFamilia ID de la família en format enter.
     * @param idProveidor ID del proveïdor en format enter.
     *
     * @throws Exception Si alguna validació falla, llença una excepció amb el
     * missatge corresponent.
     */
    public static void validarDatos(ReferenciaLogica referenciaLogica, ReferenciaDAO referenciaDAO, int idFamilia, int idProveidor) throws Exception {

        // Validar que la familia existe en la base de datos
        if (!referenciaDAO.existeFamilia(idFamilia)) {
            Excepciones.DatabaseException("La familia introducida no existe.");
            mostrarMensajeError("La familia introducida no existe. Por favor, introduce un ID de familia válido.");
            return; // Detener el flujo si la familia no existe
        }

        // Validar que el proveedor existe en la base de datos
        if (!referenciaDAO.existeProveedor(idProveidor)) {
            Excepciones.DatabaseException("El proveedor introducido no existe.");
            mostrarMensajeError("El proveedor introducido no existe. Por favor, introduce un ID de proveedor válido.");
        }
    }
}
