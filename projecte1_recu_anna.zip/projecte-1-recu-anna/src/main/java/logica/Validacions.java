/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

/**
 * Classe que proporciona diferents mètodes per validar dades relacionades amb
 * els proveïdors.
 *
 * @author Anna
 */
public class Validacions {

    /**
     * Valida si les quantitats compleixen el format correcte.
     *
     * @param quantitat Les quantitats a validar.
     * @return true si la quantitat compleix el format, false altrament.
     */
    public static boolean validarQuantitat(String quantitat) {
        if (quantitat != null) {
            String regex = "^[1-9]\\d*$";
            return quantitat.matches(regex);
        } else {
            return true;
        }
    }

    /**
     * Valida si el CIF compleix el format correcte.
     *
     * @param cif El CIF a validar.
     * @return true si el CIF compleix el format, false altrament.
     */
    public static boolean validarCif(String cif) {
        if (!cif.isEmpty()) {
            String regex = "^[ABCDEFGHJKLMNPQRSUVW]\\d{7}[0-9A-J]$";
            return cif.matches(regex);
        } else {
            return true;
        }
    }

    /**
     * Valida si el correu electrònic compleix el format correcte.
     *
     * @param correu El correu electrònic a validar.
     * @return true si el correu electrònic compleix el format, false altrament.
     */
    public static boolean validarCorreu(String correu) {
        if (!correu.isEmpty()) {
            String regex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
            return correu.matches(regex);
        } else {
            return true;
        }
    }

    /**
     * Valida si la data compleix el format correcte (YYYY-MM-DD).
     *
     * @param data La data a validar.
     * @return true si la data compleix el format, false altrament.
     */
    public static boolean validarData(String data) {
        if (data != null) {
            String regex = "^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$";
            return data.matches(regex);
        } else {
            return true;
        }
    }

    /**
     * Valida si la valoració és un nombre amb fins a dues decimals.
     *
     * @param valoracio La valoració a validar.
     * @return true si la valoració compleix el format, false altrament.
     */
    public static boolean validarValoracio(String valoracio) {
        if (valoracio != null) {
            String regex = "^\\d+(\\.\\d{1,2})?$";
            return valoracio.matches(regex);
        } else {
            return true;
        }
    }

    /**
     * Valida si els mesos de col·laboració són un nombre enter positiu.
     *
     * @param mesos Els mesos de col·laboració a validar.
     * @return true si els mesos compleixen el format, false altrament.
     */
    public static boolean validarMesos(String mesos) {
        if (mesos != null) {
            String regex = "^\\d+$";
            return mesos.matches(regex);
        } else {
            return true;
        }
    }

    public static boolean validarPreu(String preu) {
        if (preu != null) {
            String regex = "^(0|[1-9]\\d*)(\\.\\d{1,2})?$";
            return preu.matches(regex);
        } else {
            return true;
        }
    }

    /**
     * Valida si les quantitats compleixen el format correcte.
     *
     * @param quantitat Les quantitats del magatzem.
     * @param quantitatsVenudes Les quantitats venudes a validar.
     * @return true si la quantitat compleix el format, false altrament.
     */
    public static boolean validarQuantitatsVenudes(String quantitat, String quantitatsVenudes) {
        if (Integer.parseInt(quantitatsVenudes) <=  Integer.parseInt(quantitat)) {
            if (quantitat != null) {
                String regex = "^[1-9]\\d*$";
                return quantitat.matches(regex);
            } else {
                return true;
            }   
        } else{
            //No se como poner aquí un mensaje popup de que la cantidad de vendidas es superior a la cantidad de 
            // productos introducidos
            return false;
        }
        
    }
}
